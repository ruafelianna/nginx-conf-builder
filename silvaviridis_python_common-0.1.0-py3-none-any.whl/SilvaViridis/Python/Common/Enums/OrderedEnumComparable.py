from functools import total_ordering
from typing import Any, Callable

from .OrderedEnum import OrderedEnum

def OrderedEnumComparable[TEnum : OrderedEnum](
    get_order : Callable[[type[TEnum]], dict[TEnum, int]],
):
    def decorator(
        cls : type[TEnum],
    ) -> type[TEnum]:
        def __eq__(
            self : TEnum,
            other : Any,
        ) -> bool:
            if isinstance(other, cls):
                return self.name == other.name
            return NotImplemented

        def __gt__(
            self : TEnum,
            other : Any,
        ) -> bool:
            if isinstance(other, cls):
                order = get_order(cls)
                return order[self] > order[other]
            return NotImplemented

        cls.__eq__ = __eq__
        cls.__gt__ = __gt__

        return total_ordering(cls)

    return decorator
